export type ScenarioCategoryBranchType = {
  name: string;
  subCategories: string[];
};

export type ScenariosCategoryTreeType = ScenarioCategoryBranchType[];
