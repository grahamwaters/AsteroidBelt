declare module "*.css";
declare module "three/addons/controls/OrbitControls.js";
