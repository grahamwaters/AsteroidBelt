# Gravity Simulator - Under Reconstruction

Gravity Simulator, also known as Harmony of the Spheres, is currently in the process of being rewritten from scratch. Over the years, the project has accumulated a lot of technical debt, and to make it easier to develop new cool features in the future, while also making the code base more pleasant to work with, I have made the decision to repay this technical debt. The new version of the simulator will only be deployed to [production](https://gravitysimulator.org) once it has all the features that the original version has.

## Local Development

To run Gravity Simulator locally, simply run `npm start` from your terminal.

# To Be Continued!
